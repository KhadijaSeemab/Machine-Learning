import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, ConfusionMatrixDisplay, classification_report
from imblearn.over_sampling import SMOTE

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "Data Set", "creditcard.csv")

if os.path.exists(DATA_PATH):
    df = pd.read_csv(DATA_PATH)
else:
    rng = np.random.default_rng(42)
    n_normal = 5000
    n_fraud = 20
    normal = pd.DataFrame(rng.normal(0, 1, size=(n_normal, 28)), columns=[f"V{i}" for i in range(1, 29)])
    normal["Amount"] = rng.uniform(1, 500, n_normal)
    normal["Class"] = 0
    fraud = pd.DataFrame(rng.normal(3, 1.5, size=(n_fraud, 28)), columns=[f"V{i}" for i in range(1, 29)])
    fraud["Amount"] = rng.uniform(1, 2000, n_fraud)
    fraud["Class"] = 1
    df = pd.concat([normal, fraud], ignore_index=True).sample(frac=1, random_state=42).reset_index(drop=True)
    print("creditcard.csv not found in 'Data Set' folder, using a synthetic imbalanced dataset instead")
    print("Download the real dataset from https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud")
    print("and place creditcard.csv inside the 'Data Set' folder to use the real data")

print(df.shape)
print(df.head())
print(df["Class"].value_counts())
print("Fraud percentage:", df["Class"].mean() * 100)

X = df.drop("Class", axis=1)
y = df["Class"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

print("Training class distribution before SMOTE:")
print(y_train.value_counts())

smote = SMOTE(random_state=42)
X_train_res, y_train_res = smote.fit_resample(X_train, y_train)

print("Training class distribution after SMOTE:")
print(y_train_res.value_counts())

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_res)
X_test_scaled = scaler.transform(X_test)

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_scaled, y_train_res)

y_pred = knn.predict(X_test_scaled)

print("KNN (k=5) Accuracy:", accuracy_score(y_test, y_pred))
print("KNN (k=5) F1-Score:", f1_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

param_grid = {"n_neighbors": list(range(1, 16))}
grid_search = GridSearchCV(KNeighborsClassifier(), param_grid, cv=5, scoring="f1", n_jobs=-1)
grid_search.fit(X_train_scaled, y_train_res)

print("Best k:", grid_search.best_params_["n_neighbors"])

best_knn = grid_search.best_estimator_
y_pred_best = best_knn.predict(X_test_scaled)

print("Tuned KNN Accuracy:", accuracy_score(y_test, y_pred_best))
print("Tuned KNN F1-Score:", f1_score(y_test, y_pred_best))
print(classification_report(y_test, y_pred_best))

results = pd.DataFrame({
    "Model": ["KNN (k=5)", f"Tuned KNN (k={grid_search.best_params_['n_neighbors']})"],
    "Accuracy": [accuracy_score(y_test, y_pred), accuracy_score(y_test, y_pred_best)],
    "F1-Score": [f1_score(y_test, y_pred), f1_score(y_test, y_pred_best)]
})
print(results)

cm = confusion_matrix(y_test, y_pred_best)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Not Fraud", "Fraud"])
disp.plot(cmap="Blues")
plt.title("Confusion Matrix - Tuned KNN")
plt.show()
